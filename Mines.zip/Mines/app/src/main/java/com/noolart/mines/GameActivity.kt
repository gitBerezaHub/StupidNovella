package com.noolart.mines

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView

class GameActivity : Activity() {

    val first: RadioButton = findViewById(R.id.first)
    val second: RadioButton = findViewById(R.id.second)
    val third: RadioButton = findViewById(R.id.third)

    val button: Button = findViewById(R.id.buttonChoose)
    val text: TextView = findViewById(R.id.question)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_game)

        button.setOnClickListener {
            text.text = ""
        }
    }
}