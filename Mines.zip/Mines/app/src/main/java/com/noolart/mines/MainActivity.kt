package com.noolart.mines

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.Group

class MainActivity : AppCompatActivity() {

    val enterName: EditText = findViewById(R.id.enterName)
    val startButton: Button = findViewById(R.id.startButton)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
}